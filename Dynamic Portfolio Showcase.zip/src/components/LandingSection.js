import React from "react";
import { Avatar, Heading, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";

const greeting = "Hello, I am mohamed !";
const bio1 = "A full-stack developer";
const bio2 = "specialised in JavaScript and React for front-end";
const bio3 = "And Python and php for back-end";

// Implement the UI for the LandingSection component according to the instructions.
// Use a combination of Avatar, Heading and VStack components.
const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="#2A4365"
  >
    <VStack spacing={16}>
      <Avatar
        src="https://lh3.googleusercontent.com/u/0/drive-viewer/AK7aPaBY0i52Y0nUkum8h-rZFnWyLUAa9MDpswJ25SQqPK3hHt3loogG-I5EvSZuwgkEheC_IJwW-dOXJRPKR10_Sy95CfU5Bg=w1920-h907" 
        size="2xl"
        name="Mohamed SI EL KHAL"
      />

      <Heading as="h4" size="md" noOfliners={1}>
        {greeting}
      </Heading>
      <VStack spacing={6}>
        <Heading as="h1">{bio1}</Heading>
        <Heading as="h1">{bio2}</Heading>
        <Heading as="h1">{bio3}</Heading>

      </VStack>
    </VStack>
  </FullScreenSection>
);

export default LandingSection;
