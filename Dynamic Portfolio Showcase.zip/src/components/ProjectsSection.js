import React from "react";
import FullScreenSection from "./FullScreenSection";
import { Box, Heading } from "@chakra-ui/react";
import Card from "./Card";

const resumeProjects = [
  {
    title: "Interactive Seat Selector (HTML, CSS, JavaScript, Bootstrap, Font Awesome)",
    description:
      "Development of an interactive interface for users to select seats in a cinema. Design of a responsive UI for an optimal user experience on all devices.",
    year: 2023,
    getImageSrc: () => require("../images/interactive-seat-selector.jpg"),
  },
  {
    title: "Portfolio Web App (ReactJS, Node.js)",
    description:
      "Built a React-based portfolio with interactive elements, like scroll-based animation, to showcase my skills and projects. Implemented navigation links, social media integration, and smooth scrolling for a seamless user experience.",
    year: 2023,
    getImageSrc: () => require("../images/portfolio-web-app.jpg"),
  },
  {
    title: "Grade Management (PHP, phpMyAdmin, XAMPP)",
    description:
      "Created software for efficiently recording, calculating, and analyzing student grades. Implemented user-friendly interfaces for teachers and administrators.",
    year: 2022,
    getImageSrc: () => require("../images/grade-management.jpg"),
  },
  {
    title: "Full Stack E-Commerce Platform (MongoDB, Express.js, React, Node.js)",
    description:
      "Developed a full-stack e-commerce platform using MERN stack. Implemented user authentication, product listings, and cart functionality.",
    year: 2023,
    getImageSrc: () => require("../images/full-stack-e-commerce-platform.jpg"),
  },
];

const ProjectsSection = () => {
  return (
    <FullScreenSection
      backgroundColor="#14532d"
      isDarkBackground
      p={8}
      alignItems="flex-start"
      spacing={8}
    >
      <Heading as="h1" id="projects-section">
        Projects from Resume
      </Heading>
      <Box
        display="grid"
        gridTemplateColumns="repeat(2,minmax(0,1fr))"
        gridGap={8}
      >
        {resumeProjects.map((project) => (
          <Card
            key={project.title}
            title={project.title}
            description={project.description}
            year={project.year}
            imageSrc={project.getImageSrc()}
          />
        ))}
      </Box>
    </FullScreenSection>
  );
};

export default ProjectsSection;
