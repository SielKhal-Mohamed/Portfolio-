import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import {
  faGithub,
  faLinkedin,
  faMedium,
  faStackOverflow,
} from "@fortawesome/free-brands-svg-icons";
import { Box, HStack } from "@chakra-ui/react";

const socials = [
  {
    icon: faEnvelope,
    url: "mailto:sielkhal@aiac.com",
  },
  {
    icon: faGithub,
    url: "https://github.com/SielKhal-Mohamed",
  },
  {
    icon: faLinkedin,
    url: "https://www.linkedin.com/in/mohamed-sielkhal-7690b1243/?msgControlName=view_message_button&msgConversationId=2-MDNjN2RmNjUtOTBhNi00MzZlLWE5ZWQtZDBmYzFjN2JlYzcwXzAxMg%3D%3D&msgOverlay=true",
  },
  {
    icon: faMedium,
    url: "https://medium.com/@sielkhal",
  },
  {
    icon: faStackOverflow,
    url: "https://stackoverflow.com/users/22904508/si-el-khal-mohamed",
  },
];

const Header = () => {
  const handleClick = (anchor) => () => {
    const id = `${anchor}-section`;
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  return (
    <Box
      position="fixed"
      top={0}
      left={0}
      right={0}
      translateY={0}
      transitionProperty="transform"
      transitionDuration=".3s"
      transitionTimingFunction="ease-in-out"
      backgroundColor="#18181b"
    >
      <Box color="white" maxWidth="1280px" margin="0 auto">
        <HStack
          px={16}
          py={4}
          justifyContent="space-between"
          alignItems="center"
        >
          <nav>
            <HStack spacing={4}>
              {socials.map((social, index) => (
                <a
                  key={index}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <FontAwesomeIcon icon={social.icon} size="2x" />
                </a>
              ))}
            </HStack>
          </nav>
          <nav>
            <HStack spacing={8}>
              <a onClick={handleClick("projects")} href="#projects">
                Projects
              </a>
              <a onClick={handleClick("contactme")} href="#contactme">
                Contact Me
              </a>
            </HStack>
          </nav>
        </HStack>
      </Box>
    </Box>
  );
};

export default Header;
